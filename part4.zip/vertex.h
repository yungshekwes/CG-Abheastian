#ifndef VERTEX_H
#define VERTEX_H

// Defining a structure for the pyramid vertices
struct Vertex{
    float x, y, z;
    float r, g, b;
};

#endif // VERTEX_H
